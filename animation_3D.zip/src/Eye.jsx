import { useRef, useEffect, useState } from 'react'
import { useFrame, useLoader } from '@react-three/fiber'
import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader.js'
import * as THREE from 'three'

export default function Eye() {
  const outerGroup = useRef()
  const fbx = useLoader(FBXLoader, '/model/eye/OJO FINAL.fbx')
  const [ready, setReady] = useState(false)

  useEffect(() => {
    const loader = new THREE.TextureLoader()

    const corneaBaseColor = loader.load('/model/eye/textures/CORNEA_Base_Color.jpg')
    const corneaRoughness = loader.load('/model/eye/textures/CORNEA_Roughness.jpg')
    const corneaNormal = loader.load('/model/eye/textures/CORNEA_Normal_DirectX.jpg')
    const irisNormal = loader.load('/model/eye/textures/IRIS_Normal_DirectX.jpg')

    fbx.traverse((child) => {
      if (child.isMesh) {
        const matName = child.material.name.toUpperCase()

        if (matName.includes('IRIS')) {
          child.material.normalMap = irisNormal
        } else {
          child.material.map = corneaBaseColor
          child.material.roughnessMap = corneaRoughness
          child.material.normalMap = corneaNormal
        }

        child.material.needsUpdate = true
      }
    })

    // сначала масштаб
    fbx.scale.setScalar(0.01)

    // потом центрируем УЖЕ в масштабированных координатах
    const box = new THREE.Box3().setFromObject(fbx)
    const center = box.getCenter(new THREE.Vector3())
    fbx.position.sub(center)

    setReady(true)
  }, [fbx])

  useFrame(({ mouse }) => {
    if (!outerGroup.current) return
    const targetX = mouse.y * 0.6
    const targetY = mouse.x * 0.6

    outerGroup.current.rotation.x = THREE.MathUtils.lerp(outerGroup.current.rotation.x, targetX, 0.1)
    outerGroup.current.rotation.y = THREE.MathUtils.lerp(outerGroup.current.rotation.y, targetY, 0.1)
  })

  return (
    <group ref={outerGroup} rotation={[0, Math.PI / 2, 0]}>
      {/* scale больше НЕ через primitive — он теперь задан в useEffect */}
      {ready && <primitive object={fbx} />}
    </group>
  )
}